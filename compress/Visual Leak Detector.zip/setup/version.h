
#define VLDVERSION          L"2.5.1"
#define VERSION_NUMBER		2,5,1,0
#define VERSION_STRING		"2.5.1.0"
#define VERSION_COPYRIGHT	"Copyright (C) 2005-2017"

#ifndef __FILE__
!define VLD_VERSION "2.5.1"	// NSIS Script
#endif
