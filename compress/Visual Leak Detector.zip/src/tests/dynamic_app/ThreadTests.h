#pragma once

static const int NUMTHREADS = 64;

void RunLoaderLockTests(bool, bool);
